Download the latest stable release:<br />
<br />
https://github.com/DayZMod/Battleye-Filters/releases