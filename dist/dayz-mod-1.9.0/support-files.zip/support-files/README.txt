File Sources

Battleye-Filters-1.9.zip: https://github.com/DayZMod/Battleye-Filters/releases
Bec.zip: http://ibattle.org/downloads/
DaRT.zip:
  - https://forums.dayz.com/topic/68933-dart-a-lightweight-dayz-and-arma-rcon-tool-v21-11102015/
  - http://forum.swisscraft.eu/DaRT/DaRT.zip

BEServer.cfg, WatchDog.bat, basic.cfg, HiveExt.ini, server.cfg, create_addons_link.bat, UPDATE_ARMA2.BAT, UPDATE_ARMA2OA.bat:
  - https://discord.gg/BG7dCPD

SQL files:
  - https://github.com/DayZMod/DayZ/releases/tag/1.9.0